Jeu d'��chec locale: http://www-ens.iro.umontreal.ca/~wangqiao/ift3225/tp3/index.html

Par Qiao Wang 20095140

Le jeu se faire entre 2 joueurs sur la m��me machine.

Vous pouvez consulter la page wikipedia pour les mouvements des pi��ces. https: //fr.wikipedia.org/wiki/%C3%89checs#R%C3%A8gles_du_jeu

Vous ne pouvez pas effectuer les  coups sp��ciaux comme le roque, promotion, en passant ou pat.
Le jeu se termine quand le roi est mat.

Le bouton "Afficher les donn��es json" fait un requete ajax au lien des donn��es json.

Le code est vastement inspir�� du tutorial Develop Two Player Chess Game Application with React Js par Talha Awan.

Le lien vers l'article: https://www.techighness.com/post/develop-two-player-chess-game-with-react-js/